Revised AngularJS Workshop
