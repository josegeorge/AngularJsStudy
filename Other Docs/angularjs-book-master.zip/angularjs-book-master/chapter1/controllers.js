function HelloController($scope) {
  $scope.greeting = { text: 'Hello' };
}